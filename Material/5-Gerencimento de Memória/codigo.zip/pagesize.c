#include <unistd.h>
#include <stdio.h>
#include <math.h>

int global;

int main() {
  int pagesize, bits_pagina, address_bits;

  pagesize = getpagesize();

  address_bits = 8 * sizeof (char*);

  printf("Endereço de global: %p\n", &global);
  printf("Tamanho de uma página %d\n", pagesize);
  printf("Endereço: %d bytes, %d bits\n", sizeof(char*), address_bits);
  
  return 0;
}
