/*
 * Qual abordagem para aloca��o?
 */

#include <stdlib.h>
#include <stdio.h>

int main() {
  int *s1, *s2, *s3, *s4;

  s1 = (int *) malloc (sizeof(int) * 1000);
  printf ("s1: %p\n", (void*) s1);
  s2 = (int *) malloc (sizeof(int) * 1000);
  printf ("s2: %p\n", (void*) s2);
  s3 = (int *) malloc (sizeof(int) * 1000);
  printf ("s3: %p\n", (void*) s3);
  free(s1);
  s4 = (int *) malloc (sizeof(int) * 1000);
  printf ("s4: %p\n", (void*) s4);

  return 0;
}
